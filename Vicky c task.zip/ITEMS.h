const char *p_in="\n\tBOOK_DETAILE\nNAME:%[^\n]\nId.NO:%[^\n]\nPRICE:%[^\n]\nQUANTITY:%[^\n]\n\n";
const char *p_out="\n\tBOOK_DETAILE\nNAME:%s\nId.NO:%s\nPRICE:%s\nQUANTITY:%s\n\n";
typedef struct Item
{
	char i_Name[20],i_no[10],i_cost[10],i_quant[10];
} Items;
Items p1,p2;

int ADD_ITEM(const char *file_name)
{
	FILE *file;
	file=fopen(file_name,"w+");
NAME:
	printf("\n\n\t REGISTER FORM FOR NEW BOOKS\n\n\n\tNAME\t\t:\t");
	{
		scanf("%s",p1.i_Name);
		for(i=0; m1.Name[i]!='\0'; i++)
		{
			if((p1.i_Name[i]>=65) && (p1.i_Name[i]<=90) || (p1.i_Name[i]<=32) || (p1.i_Name[i]>=97) && (p1.i_Name[i]<=122))
			{
				p1.i_Name[i];
			}
			else
			{
				printf("\tNOTE: Name cotains only caps\n");
				goto NAME;
			}
		}
	}
BOOK_ID:
	printf("\n\tBOOK.ID\t\t:\t");
	//	scanf("%d",&p1.i_no);
	{
		scanf("%s",p1.i_no);
		for(i=0; p1.i_no[i]!='\0'; i++)
		{
			if((p1.i_no[i]>=48) && (p1.i_no[i]<=57))
			{
				p1.i_no[i];
			}
			else
			{
				printf("\tNOTE: BOOK_ID should be number\n");
				goto BOOK_ID;
			}
		}
	}
BOOK_PRICE:	
	printf("\n\tCost\t\t:\t");
	{
		scanf("%s",p1.i_cost);
		for(i=0; p1.i_cost[i]!='\0'; i++)
		{
			if((p1.i_cost[i]>=48) && (p1.i_cost[i]<=57))
			{
				p1.i_cost[i];
			}
			else
			{
				printf("\tNOTE: BOOK_PRICE should be number\n");
				goto BOOK_PRICE;
			}
		}
	}
BOOK_QUNTITY:	
	printf("\n\tQuantity\t:\t");	
	{
		scanf("%s",p1.i_quant);
		for(i=0; p1.i_quant[i]!='\0'; i++)
		{
			if((p1.i_quant[i]>=48) && (p1.i_quant[i]<=57))
			{
				p1.i_quant[i];
			}
			else
			{
				printf("\n\tNOTE: BOOK_QUNTITY should be number\n");
				goto BOOK_PRICE;
			}
		}
	}
	printf("\n\n\tBOOK DETAILS STORED SUCCESSFULLY\n\n");
	if(file==NULL)
	{
		return 1;
	}
	fprintf(file,p_out,p1.i_Name,p1.i_no,p1.i_cost,p1.i_quant);
	fclose(file);
}

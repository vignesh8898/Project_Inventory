const char *m_in="\n\tUSER DETAILES\n NAME:%[^\n]\nEM_ID:%[^\n]\nDesignation:%[^\n]\nUSER NAME:%[^\n]\nPASS WORD:%[^\n]\n\n";
const char *m_out="\n\tUSER DETAILES\nNAME:%s\nEM_ID:%s\nDesignation:%s\nUSER NAME:%s\nPASS WORD:%s\n\n";
int i;
typedef struct Member
{
	char Name[50],EM_ID[20],Designation[30],u_name[20],pass[20];
} Members;
Members m1,m2;
int Register(const char *file_name1)
{
	FILE *file;
	file=fopen(file_name1,"w+");
NAME:
	printf("\n\n\t REGISTER FORM FOR NEW USER\n\n\n\tNAME\t\t\t:");
	{
		scanf(" %s",m1.Name);
		for(i=0; m1.Name[i]!='\0'; i++)
		{
			if((m1.Name[i]>=65) && (m1.Name[i]<=90) || (m1.Name[i]<=32) || (m1.Name[i]>=97) && (m1.Name[i]<=122))
				m1.Name[i];
			else
			{
				printf("\tNOTE: Name cotains only caps\n");
				goto NAME;
			}
		}
	}
ID:
	printf("\n\tEMP.ID\t\t\t:");
	{
		scanf("%s",m1.EM_ID);
		for(i=0; m1.EM_ID[i]!='\0'; i++)
		{
			if((m1.EM_ID[i]>=48) && (m1.EM_ID[i]<=57))
				m1.EM_ID[i];
			else
			{
				printf("\tNOTE: EMP.ID should be 5 digit number\n");
				goto ID;
			}
		}
	}
DESIGNATION:
	printf("\n\tDesignation\t\t:");
	{
		scanf("%s",m1.Designation);
		for(i=0; m1.Designation[i]!='\0'; i++)
		{
			if(((m1.Designation[i]>=97) && (m1.Designation[i]<=122))||((m1.Designation[i]>=65) && (m1.Designation[i]<=90)) )
				m1.Designation[i];
			else
			{
				printf("\tNOTE: Designation should be a position in shop\n");
				goto DESIGNATION;
			}
		}
	}
USER:
	printf("\n\tUser Name\t\t:");
	{
		scanf("%s",m1.u_name);
		for(i=0; m1.u_name[i]!='\0'; i++)
		{
			if(((m1.u_name[i]>=97) && (m1.u_name[i]<=122)) || ((m1.u_name[i]>=48) && (m1.u_name[i]<=57)) || ((m1.u_name[i]>=65) && (m1.u_name[i]<=90)))
				m1.u_name[i];
			else
			{
				printf("\tNOTE:Invalid  User name\n");
				goto USER;
			}
		}
	}
PASS:
	{
	printf("\n\tEnter pass word\t\t:");
		char ch[5];
		scanf("%s",ch);
	{
	printf("\n\tReenter pass word\t:");
		scanf("%s",m1.pass);
		if(strcmp(ch,m1.pass)==0)
		{
		int count=0;
		for(i=0; m1.pass[i]!='\0'; i++)
		{
			count++;
			if((m1.pass[i]>=48) && (m1.pass[i]<=57))
				m1.pass[i];
			else
			{
				printf("\tNOTE: Password should be 4 digit Number only\n");
				goto PASS;
			}
		}
		if(count!=4)
		{
			printf("\tNOTE: Password should be 4 digit Number\n");
			goto PASS;
		}
	}
		}
	}
	printf("\n\n\tUSER DETAILS STORED SUCCESSFULLY\n\n");
	if(file==NULL)
		return 1;
	fprintf(file,m_out,m1.Name,m1.EM_ID,m1.Designation,m1.u_name,m1.pass);
	fclose(file);
}

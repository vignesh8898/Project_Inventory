
int user_limit,i;
void SELECT(int);
	enum uname{memb1=1,memb2,memb3,memb4,memb5,memb6,memb7,memb8,memb9,memb10,memb11,memb12,memb13,memb14,memb15}Un;

	const char *U_name[]={"dummy"  ,"Vignesh User shop\\User_data1.txt","Vignesh User shop\\User_data2.txt","Vignesh User shop\\User_data3.txt",
									"Vignesh User shop\\User_data4.txt","Vignesh User shop\\User_data5.txt","Vignesh User shop\\User_data6.txt",
									"Vignesh User shop\\User_data7.txt","Vignesh User shop\\User_data8.txt","Vignesh User shop\\User_data9.txt",
									"Vignesh User shop\\User_data10.txt","Vignesh User shop\\User_data11.txt","Vignesh User shop\\User_data12.txt",
									"Vignesh User shop\\User_data13.txt","Vignesh User shop\\User_data14.txt","Vignesh User shop\\User_data15.txt"};
int AddUser()
{    
	printf("\n\n\tNumber of Users want to add \n\t(note:Users < 15)\t:");
	scanf("%d",&user_limit);
	for(Un=1;Un<=user_limit;Un++)
	 {
	if(Un>=memb1 && Un<=memb15)
		Register(U_name[Un]);
	 }
} 
int ModifyUser()
{
	int K=1;
	char uname[10];
	printf("\n\n\tEnter user id want to modify\t:");
	scanf("%s",uname);
	for(Un=1;(K!=2&&Un<=15);Un++)
	 {
		if(Un>=memb1 && Un<=memb15)
			K=SELECT_USER(uname,Un);
	 }
 
	 if(K==0)
	 {
		printf("\n\tWrorng User id or pass word.\n");
		ModifyUser();
	 }	 
}
int DELETEUser()
{
	int K=1;
	char uname[10];
	printf("\n\n\tEnter user id want to modify\t:");
	scanf("%s",uname);
	for(Un=1;(K!=2&&Un<=15);Un++)
	 {
		if(Un>=memb1 && Un<=memb15)
			K=SELECTD(uname,Un);
	 }
	 if(K==0)
	 {
		printf("\n\t\tWrorng User id or pass word.\n");
		DELETEUser();
	 } 
}
int SELECT_USER(char uname[],int Un)
{
		FILE *file;
		file=fopen(U_name[Un],"r");
		if(file==NULL)
			printf("\n\n\tError in file\t:");
		fscanf(file,m_in,m2.Name,m2.EM_ID,m2.Designation,m2.u_name,m2.pass);
		if(strcmp(uname,m2.u_name)==0)
		{
			char pas[10];
			printf("\n\tEnter user PIN\t\t\t:");
			scanf("%s",pas);
			if(strcmp(pas,m2.pass)==0)
			{
				printf("\n\t\t USER DETAILES\n \n\tNAME\t\t:%s\n\n\tEMP.ID\t\t:%s\n\n\tDESIGNATION\t:%s\n\n\tUSER NAME\t:%s\n\n",m2.Name,m2.EM_ID,m2.Designation,m2.u_name);
				Register(U_name[Un]);	
				option();
				fclose(file);
				return 2;			
			}
			else
				return 0;
		}
		else
			return 0;
}
int SELECTD(char uname[],int Un)
{
		FILE *file;
		file=fopen(U_name[Un],"r");
		if(file==NULL)
			printf("\n\n\tError in file\t:");
		fscanf(file,m_in,m2.Name,m2.EM_ID,m2.Designation,m2.u_name,m2.pass);
		if(strcmp(uname,m2.u_name)==0)
		{
			char pas[10];
		printf("\n\tEnter user PIN\t\t\t:");
		scanf("%s",pas);
			if(strcmp(pas,m2.pass)==0)
			{
				printf("\n\t\t USER DETAILES\n \n\tNAME\t\t:%s\n\n\tEMP.ID\t\t:%s\n\n\tDESIGNATION\t:%s\n\n\tUSER NAME\t:%s\n\n",m2.Name,m2.EM_ID,m2.Designation,m2.u_name);
				FILE *file;
				file=fopen(U_name[Un],"w+");
				if(file==NULL)
				return 1;
				fclose(file);
				printf("\n\tThe data of this user deleted sucessfully");
				option();
				return 2;			
			}
			else
				return 0;
		}
		else
			return 0;	
}

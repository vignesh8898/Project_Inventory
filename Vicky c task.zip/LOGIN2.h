int Total=0;
int LOGIN_2()
{
	int K=1;
	char uname[10];
	printf("\n\n\t\t\tLOG_IN 2\t\n");
	printf("\n\n\t\tEnter user id\t\t:");
	scanf("%s",uname);
	for(Un=1;(K!=2 && Un<=15);Un++)
	 {
		if(Un>=memb1 && Un<=memb15)
			K= SELECTL(uname,Un);
	 }
	 if(K==0)
	 {
		printf("\n\t\tWrorng User id or pass word.\n");
		LOGIN_2();
	 }
}
int SELECTL(char uname[],int Un)
{
	FILE *file;
	file=fopen(U_name[Un],"r");
	if(file==NULL)
	printf("\n\n\tError in file\t:");
	fscanf(file,m_in,m2.Name,m2.EM_ID,m2.Designation,m2.u_name,m2.pass);
	if(strcmp(uname,m2.u_name)==0)
		{
			char pas[10];
			printf("\n\t\tEnter user PIN\t\t:");
			scanf("%s",pas);
			if(strcmp(pas,m2.pass)==0)
			{
				printf("\n\t\t\tHi...%s\n",m2.Name);
					fclose(file);
				NK:
				printf("\n\t\tPress 1 For Book Menu");
				int nk;
				scanf("%d",&nk);
					if(nk==1)
					{
						printf("\n\n\t\t\t\t\tLIST OF BOOKS \n\n");
						printf("\n\t\tBOOK.ID\t\tBOOK.COST\tBOOK.QTY\tBOOK.NAME\n\n");
						for(fn=1;fn<=15;fn++)
							{
								FILE *file;
								file=fopen(F_name[fn],"r");
								if(file==NULL)
								printf("\n\n\tError in file\t:");
								fscanf(file,p_in,p2.i_Name,p2.i_no,p2.i_cost,p2.i_quant);
								printf("\n\t\t%s\t\t%s\t\t%s\t\t%s\n",p2.i_no,p2.i_cost,p2.i_quant,p2.i_Name);
								fclose(file);
							}
					}
					else
					{
						goto NK;
					}
						printf("\n\n.........................................................................................\n\n\t\tStarting New Bill: \n\n");
						return 2;			
			}
			else
				return 0;
		}
		else
			return 0;
}
void BILL()
{
	char Sel_id[5];
	int K=1,z,y;	
	K_ID:
		{
		printf("\t\tSelect Book Id.no\t:");
		scanf("%s",Sel_id);
		for(i=0; Sel_id[i]!='\0'; i++)
			{
				if((Sel_id[i]>=48) && (Sel_id[i]<=57))
				{
					Sel_id[i];
				}
				else
				{
					printf("\n\tNOTE: BOOK_ID should be number\n");
					goto K_ID;
				}
			}
		}
			for(fn=1;(K!=2&&fn<=15);fn++)
		 {
			if(fn>=file1 && fn<=file15)
				K=SELECT_book(Sel_id,fn);
		 }	 
		 if(K==0)
		 {
			printf("\n\t\tInvalid entry.\n");
	    	goto K_ID;
		 }
		 X:
		 printf("\n\n\t\t1.Add Book to Bill\n\t\t2.Close the Bill\n\n\t\t\tChoose\t:");
		 scanf("%d",&z);
		 if(z==1)
		 {
		 	BILL();
		 }
		 	else if(z==2)
		 	{
				printf("\n\n\t\tTotal of Bill: Rs.%d",Total);		 	
			}
				else 
				{
				 	printf("\n\n\t\tInvalid Entry");
				 	goto X;
				 }
		 H:
		 printf("\n\n\t\t1.Start new Bill\n\t\t2.User logout\n\n\t\t\tChoose\t:");
		 scanf("%d",&y);
		 if(y==1)
		 {
		 	Total=0;
			printf("\n\n.........................................................................................\n\n\t\tStarting New Bill: \n\n");
		 	BILL();
		 }
			 else if(y==2)
			 {
				printf("\n\n\t\t Logging out...");	
				main();	 	
			 }
				 else 
				 {
				 	printf("\n\n\t\tInvalid Entry");
				 	goto H;
				 }
}
int SELECT_book(char Sel_id[],int fn)
{
	int QTY;
	FILE *file;
		file=fopen(F_name[fn],"r");
		if(file==NULL)
		printf("\n\n\tError in file\t:");
		fscanf(file,p_in,p2.i_Name,p2.i_no,p2.i_cost,p2.i_quant);
		if(strcmp(Sel_id,p2.i_no)==0)
		{			
			int QT=atoi(p2.i_quant);
			int RT=atoi(p2.i_cost);
			QW:
			printf("\n\t\t%s(RS.%d) is selected\n\t\t\tQuatity\t\t:",p2.i_Name,RT);
			scanf("%d",&QTY);
			if(QTY>QT)
			{
				printf("\n\t\t\tQuantity not available");
				goto QW;
			}
			printf("\n\t\t Price For %s\t:%d",p2.i_Name,(RT*QTY));
			Total+=(RT*QTY);
			QT-=QTY;
			char i_Name[20],i_no[5],i_cost[5],i_quant[5];
			strcpy(i_Name,p2.i_Name);
			strcpy(i_no,p2.i_no);
			strcpy(i_cost,p2.i_cost);
			sprintf(i_quant,"%d",QT);
			FILE *file;
			file=fopen(F_name[fn],"w+");
			strcpy(p1.i_Name,i_Name);
			strcpy(p1.i_no,i_no);
			strcpy(p1.i_cost,i_cost);
			strcpy(p1.i_quant,i_quant);
			if(file==NULL)
			return 1;
			fprintf(file,p_out,p1.i_Name,p1.i_no,p1.i_cost,p1.i_quant);
			fclose(file);
			return 2;			
		}
		else
			return 0;
}

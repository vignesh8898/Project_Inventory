int n,i;
void SELECT(int);
	enum fname{file1=1,file2,file3,file4,file5,file6,file7,file8,file9,file10,file11,file12,file13,file14,file15}fn;

	const char *F_name[]={"dummy"  ,"Vignesh book shop\\Book_data1.txt","Vignesh book shop\\Book_data2.txt","Vignesh book shop\\Book_data3.txt",
									"Vignesh book shop\\Book_data4.txt","Vignesh book shop\\Book_data5.txt","Vignesh book shop\\Book_data6.txt",
									"Vignesh book shop\\Book_data7.txt","Vignesh book shop\\Book_data8.txt","Vignesh book shop\\Book_data9.txt",
									"Vignesh book shop\\Book_data10.txt","Vignesh book shop\\Book_data11.txt","Vignesh book shop\\Book_data12.txt",
									"Vignesh book shop\\Book_data13.txt","Vignesh book shop\\Book_data14.txt","Vignesh book shop\\Book_data15.txt"};
int option()
{
	int A,B;
Y:
	printf("\n\t\t\tSHOP MENU\n\n\t1. ADD BOOKS\t\t(press 1)\n\t2. MODIFY BOOKS\t\t(press 2)\n\t3. DELETE BOOK\t\t(press 3)\n\t4. LIST OF BOOKS\t(press 4)\n\t5. SETTINGS\t\t(press 5)\n\t6. LOGOUT\t\t(press 6)\n\n\t Chose your option\t:");
	scanf("%d",&A);
	switch (A)
	{
		case 1:
			{
			printf("\n\n\tNumber of books want to add \n\t(note:books < 15)\t:");
			scanf("%d",&n);
			for(fn=1;fn<=n;fn++)
			 {
				if(fn>=file1 && fn<=file15)
				ADD_ITEM(F_name[fn]);
				goto Y;
			 }
			break;
			}
		case 2:
			{
			printf("\n\n\tEnter id of  books want to modify ");
			scanf("%d",&n);
			printf("\n\n\t\tDetailes of selected book\t\n");
			SELECT(n);
			ADD_ITEM(F_name[fn]);
			break;
			}
		case 3:
			{
			printf("\n\nEnter id of  books want to delete ");
			scanf("%d",&n);
			printf("\n\n\t\tDetailes of selected book\t\n");
			SELECT(n);
		 	FILE *file;
			file=fopen(F_name[fn],"w+");
			if(file==NULL)
				return 1;
			fclose(file);
			goto Y;	
			break;
			}
		case 4:
			{
			printf("\n\n\tLIST OF BOOKS \n\n");
			printf("\n\t\tBOOK.ID\t\tBOOK.COST\tBOOK.QTY\tBOOK.NAME\n\n");
			for(fn=1;fn<=15;fn++)
				{
					FILE *file;
					file=fopen(F_name[fn],"r");
					if(file==NULL)
					printf("\n\n\tError in file\t:");
					fscanf(file,p_in,p2.i_Name,p2.i_no,p2.i_cost,p2.i_quant);
					printf("\n\t\t%s\t\t%s\t\t%s\t\t%s\n",p2.i_no,p2.i_cost,p2.i_quant,p2.i_Name);
					fclose(file);
				}
				goto Y;
			break;
			}
		case 5:
		{
		Q:
				printf("\n\t\t\tSETTINGS\n\n\t1. Change Login 1 User Name & Password\t(press 1)\n\n\t2. Manage User\t\t\t\t(press 2)\n\n\t Chose your option\t:");
				scanf("%d",&B);
				switch (B)
				{
					case 1:
						{
							printf("\n\t Login again to change user name and password");
							sup_id();
							sup_write();
							break;
						}
					case 2:
					{
					I:
							printf("\n\t\t\tUser Management\n\n\t1. Add User\t\t(press 1)\n\n\t2. Modify User\t\t(press 2)\n\n\t3. Delete User\t\t(press 3)\n\n\tChose your option\t:");
							int i;
							scanf("%d",&i);
								switch(i)
								{
									case 1:
										{
											AddUser();
											break;
										}
									case 2:
										{
											ModifyUser();
											break;
										}
									case 3:
										{
											DELETEUser();			
											break;
										}
									default:
										{
											printf("Invalid entry");
											goto I;
											break;
										}
								}
								break;
						}
					default:
							{
								printf("\n\t\t\tInvalid Entry");
								goto Q;
								break;
							}
				}
				goto Y;
				break;
			}
		case 6:
			{
				printf("\n\t\t\tLOGING OUT....");
				main();
				break;
			}
	
		default:
			{
			printf("\n\tInvalid entry\n\n ");
			goto Y;
			break;
			}
	}
	return 1;
}
void SELECT(int n)
{
		fn=n;
		FILE *file;
		file=fopen(F_name[fn],"r");
		if(file==NULL)
			printf("\n\n\tError in file\t:");
		fscanf(file,p_in,p2.i_Name,p2.i_no,p2.i_cost,p2.i_quant);
		printf("\n\n\t BOOK DETAILE\n\n\tBOOK.NAME\t:%s\n\tBOOK.ID\t\t:%s\n\tBOOK.COST\t:%s\n\tBOOK.QTY\t:%s\n\n",p2.i_Name,p2.i_no,p2.i_cost,p2.i_quant);
		fclose(file);
}		

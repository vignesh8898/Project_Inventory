/*	NAME	: VIGNESH P
	DATE	: 06-07-2023
	TASK	: Number convertion
*/

#include<stdio.h>
#include<string.h>
int decimal,octal,o,i,s,power=1;
char hexa[30],binary[20];
int binary_decimal(char binary[])
{
	for( i=(strlen(binary)-1);i>=0;i--)
	{
		decimal+=((binary[i]-48)*power);
		power=power*2;
	}
	printf("decimal=%d",decimal);
	return decimal;
}

int decimal_octal(int decimal)
{
	for( i=1;decimal!=0;i=i*10)
	{
		octal=octal+(decimal%8)*i;
		decimal=decimal/8;
	}
	printf("\noctal=%d",octal);	
	return octal;
}
char* decimal_hexa(int decimal)
{
		int p,j;
	for( i=0;decimal!=0;i++)
	{
		p=decimal%16;
		if(p<10)
		hexa[i]=p+48;
		else
		hexa[i]=p+55;	
		decimal/=16;	
	}
	printf("\nhexa=%s",strrev(hexa));	
	return hexa;
}
void decimal_binary(int decimal)
{
	for (i=0;decimal!=0;i++)
	{
		
		binary[i]=(decimal%2)+48;
		decimal/=2;
	}
	binary[i+1]='\0';
	printf("\nbinary=%s",strrev(binary));	
}
int octal_decimal(int octal)
{
	decimal=0;
	printf("\noctal=%d",octal);	
	for(i=1;octal!=0;i*=8)
	{
		int reminder=octal%10;
		decimal+=(reminder*i);
		octal/=10;
	}
	printf("\ndecimal=%d",decimal);	
	return decimal;
}
int hexa_decimal(char hexa[])
{
	decimal=0;
	for( i=(strlen(hexa)-1);i>=0;i--)
	{
		if(hexa[i]>=65 &&hexa[i]<=70)
		decimal+=((hexa[i]-55)*power);
		if(hexa[i]>=48 && hexa[i]<=57)
		decimal+=((hexa[i]-48)*power);
		power=power*16;
	}
	printf("\ndecimal=%d",decimal);
	return decimal;	
}
void main()
{
	printf("\n\n\t\tNUMBER CONVERTER\n\nSelect which number you want to convert....\n\nBy Press(1 to 4) \n\t1.Binary\n\t2.Octal\n\t3.Decimal\n\t4.Hexa decimal\n\n\tSelect:");
	scanf("%d",&i);
	switch(i)
	{
	case 1:
	{
	printf("Enter binary number=");
	scanf("%s",&binary);
	s=binary_decimal(binary);
	o=decimal_octal(s);
	char* hexa=decimal_hexa(s);
	break;
	}
	case 2:
		{
	printf("Enter Octal number=");
	scanf("%d",&o);
	s=octal_decimal(o);
	decimal_binary(s);	
	char* hexa=decimal_hexa(s);	
	break;
		}
	case 3:
		{
	printf("Enter Decimal number=");
	scanf("%d",&s);
	decimal_binary(s);
	o=decimal_octal(s);	
	char* hexa=decimal_hexa(s);
	break;
}
	case 4:
		{
	printf("enter hexa number=");
	scanf("%s",hexa);
	s=hexa_decimal(hexa);
	o=decimal_octal(s);
	decimal_binary(s);	
	break;
}
}
}


typedef struct Super
{
	char Name[20],pass[20];
} super;
super s1,s2;
char R[5];
int sup_id()
{
	printf("\n\n\t\t\tLOG_IN 1\t\n");
	FILE *file;
	file=fopen("confidential.txt","r");
	if(file==NULL)
	{
		printf("\n\n\tError in file\t:");
	}
	fscanf(file,"%s\n%s",s2.Name,s2.pass);
	char Id [20],pas [20];
	printf("\n\n\tEnter your USER ID\t:");
	scanf("%s",Id);
	if(strcmp(Id,s2.Name)==0)
	{
		printf("\n\tEnter your PIN\t\t:");
		scanf("%s",pas);
		if(strcmp(pas,s2.pass)==0)
		{
			printf("\n\t\tSUPERVISOR LOGIN SUCESSFULL\n\n");
		}
		else
		{
			printf("\n\tWrorng pass word.\n");
			return sup_id();
		}
	}
	else
	{
		printf("\n\tWrorng  id.\n\n");
		return sup_id();
	}
	fclose(file);
}
void sup_write()
{
	FILE *file;
	file=fopen("confidential.txt","w+");
NAM:
	printf("\n\n\tEnter new User name\t\t:\t");
	{
		scanf("%s",s1.Name);
		for(i=0; s1.Name[i]!='\0'; i++)
		{
			if((s1.Name[i]>=65) && (s1.Name[i]<=90) || (s1.Name[i]<=32) || (s1.Name[i]>=97) && (s1.Name[i]<=122))
			{
				s1.Name[i];
			}
			else
			{
				printf("\tNOTE: invalid entry\n");
				goto NAM;
			}
		}
	}
PAS:
	printf("\n\tEnter new Pass word\t\t:\t");
	{
		scanf("%s",s1.pass);
		int count=0;
		for(i=0; s1.pass[i]!='\0'; i++)
		{
			count++;
			if((s1.pass[i]>=48) && (s1.pass[i]<=57))
			{
				s1.pass[i];
			}
			else
			{
				printf("\tNOTE: Password should be 4 digit Number only\n");
				goto PAS;
			}
		}
		if(count!=4)
		{
			printf("\tNOTE: Password should be 4 digit Number\n");
			goto PAS;
		}
		printf("\n\tRenter new Pass word\t\t:\t");
		scanf("%s",R);
		if(strcmp(R,s1.pass)==0)
			printf("\n\n\tNew user name and password changed succesfully\n\n");
		else
			goto PAS;
	}
	fprintf(file,"%s\n%s",s1.Name,s1.pass);
	fclose(file);
}
int CREATE_folder1()
{
	const char* Folder1="Vignesh User shop";
	int status= _mkdir(Folder1);
	const char* Folder2="Vignesh book shop";
	status= _mkdir(Folder2);
	return 0;
}

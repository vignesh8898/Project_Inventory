//int id()
//{
//	FILE *file;
//	file=fopen("Member_data.txt","r");
//	if(file==NULL)
//	{
//		printf("\n\n\tError in file\t:");
//	}
//	fscanf(file,m_in,m2.Name,m2.EM_ID,m2.Designation,m2.u_name,m2.pass);
//	char Id [20];
//	char pas [20];
//	printf("\n\n\tEnter your USER ID\t:\t");
//	scanf("%s",Id);
//	if(strcmp(Id,m2.u_name)==0)
//	{
//		printf("\n\tEnter user PIN\t\t:\t");
//		scanf("%s",pas);
//		if(strcmp(pas,m2.pass)==0)
//		{
//			printf("\n\t\t USER DETAILES\n \n\tNAME\t\t:%s\n\n\tEMP.ID\t\t:%s\n\n\tDESIGNATION\t:%s\n\n\tUSER NAME\t:%s\n\n",m2.Name,m2.EM_ID,m2.Designation,m2.u_name);
//			// option();
//		}
//		else
//		{
//			printf("\n\tWrorng pass word.\n");
//			return id();
//		}
//	}
//	else
//	{
//		printf("\n\tWrorng user id.\n\n");
//		return id();
//	}
//	fclose(file);
//}

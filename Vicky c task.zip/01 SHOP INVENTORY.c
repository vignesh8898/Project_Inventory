/*	NAME	: VIGNESH P
	DATE	: 21-07-2023
	TASK	: SHOP INVENTORY MANAGEMENT */
			
#include<stdio.h>   
#include<stdlib.h>   
#include<direct.h>   
#include<string.h>
#include"MEMBERS.h"
#include"USER_MANAGE.h"
#include"ITEMS.h"
#include"OPTIONS_L1.h"
#include"LOGIN2.h"       
#include"Confidential.h"       
void main()
{
		
	int L;	
	CREATE_folder1();
	printf("\n\n\t\t***WELCOME TO _BOOK_HOUSE_***\n\n\t   [ Books: Your Gateway to Imagination! ]\n\n");
	WELCOME:
	{
		printf("\n\t\t1.ADMIN(LOGIN 1)\t(press1)\n\n\t\t2.USER(LOGIN 2)\t\t(press2)\n\n\t\tChoose\t\t:");
		scanf("%d",&L);
		switch (L)
			{
				case 1:
					{
						sup_id();
						option();
						break;
					}
				case 2:
					{
						LOGIN_2();
						BILL();
						break;
					}
				default:
					{
						printf("\n\t\t INVALID ENTRY");
						goto WELCOME;
						break;
					}
			}

	}
}
